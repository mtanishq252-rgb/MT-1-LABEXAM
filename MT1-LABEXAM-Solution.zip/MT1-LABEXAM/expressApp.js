import express from "express";

const app = express();
const PORT = 4000;

// Middleware: parse incoming JSON request bodies.
app.use(express.json());

// In-memory sample data (no database is required).
const foods = [
  { id: 1, foodName: "Pizza", category: "Fast Food", price: 250, availability: true },
  { id: 2, foodName: "Burger", category: "Fast Food", price: 120, availability: true },
  { id: 3, foodName: "Pasta", category: "Italian", price: 180, availability: false }
];

function validateFood(food) {
  return food &&
    food.id !== undefined &&
    typeof food.foodName === "string" && food.foodName.trim() !== "" &&
    typeof food.category === "string" && food.category.trim() !== "" &&
    typeof food.price === "number" && Number.isFinite(food.price) && food.price > 0 &&
    typeof food.availability === "boolean";
}

// GET /foods - retrieve all food items.
app.get("/foods", (req, res) => {
  res.status(200).json(foods);
});

// GET /foods/:id - retrieve one food item by ID.
app.get("/foods/:id", (req, res) => {
  const food = foods.find((item) => String(item.id) === req.params.id);

  if (!food) {
    return res.status(404).json({ message: "Food item not found." });
  }

  res.status(200).json(food);
});

// POST /foods - add a new food item.
app.post("/foods", (req, res) => {
  const newFood = req.body;

  if (!validateFood(newFood)) {
    return res.status(400).json({
      message: "Invalid food data. Required: id, foodName, category, positive price, availability (boolean)."
    });
  }

  if (foods.some((item) => String(item.id) === String(newFood.id))) {
    return res.status(400).json({ message: "A food item with this ID already exists." });
  }

  foods.push(newFood);
  res.status(201).json({
    message: "Food item added successfully",
    food: newFood
  });
});

// PUT /foods/:id - update an existing food item.
app.put("/foods/:id", (req, res) => {
  const index = foods.findIndex((item) => String(item.id) === req.params.id);

  if (index === -1) {
    return res.status(404).json({ message: "Food item not found." });
  }

  const updatedFood = { ...foods[index], ...req.body, id: foods[index].id };

  if (!validateFood(updatedFood)) {
    return res.status(400).json({
      message: "Invalid food data. Food name, category, positive price and boolean availability are required."
    });
  }

  foods[index] = updatedFood;
  res.status(200).json({
    message: "Food item updated successfully",
    food: updatedFood
  });
});

// DELETE /foods/:id - delete a food item.
app.delete("/foods/:id", (req, res) => {
  const index = foods.findIndex((item) => String(item.id) === req.params.id);

  if (index === -1) {
    return res.status(404).json({ message: "Food item not found." });
  }

  const deletedFood = foods.splice(index, 1)[0];
  res.status(200).json({
    message: "Food item deleted successfully",
    food: deletedFood
  });
});

// Return a clear response for unknown routes.
app.use((req, res) => {
  res.status(404).json({ message: "Route not found." });
});

// Handle malformed JSON sent to express.json().
app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    return res.status(400).json({ message: "Invalid JSON request body." });
  }
  next(error);
});

app.listen(PORT, () => {
  console.log(`Express Server running at http://localhost:${PORT}`);
});
