# MT1-LABEXAM — Online Food Ordering Web Application

A Node.js lab-exam project demonstrating the built-in `http` and `fs` modules and Express.js REST APIs. No database is used; records are stored in JavaScript arrays.

## Project structure

```text
MT1-LABEXAM/
├── .gitignore
├── package.json
├── httpServer.js
├── expressApp.js
├── public/
│   └── menu.html
└── screenshots/
    └── README.md
```

## Requirements

- Install Node.js (LTS recommended).
- Use a terminal in this project folder.

## Install dependencies

```bash
npm install
```

## Part A — Native HTTP server (port 3000)

```bash
node httpServer.js
```

Open these URLs in your browser:

- http://localhost:3000/ — welcome page
- http://localhost:3000/foods — available food items in JSON
- http://localhost:3000/about — restaurant information
- http://localhost:3000/menu — serves `public/menu.html` using `fs.readFile()`

To add a food item, send a `POST` request to `http://localhost:3000/add-food` with Body → raw → JSON:

```json
{
  "id": 4,
  "foodName": "Cold Coffee",
  "category": "Beverage",
  "price": 120,
  "availability": true
}
```

## Part B — Express REST API (port 4000)

Open a second terminal in the same folder:

```bash
node expressApp.js
```

The API endpoints are:

| Method | URL | Purpose |
|---|---|---|
| GET | `http://localhost:4000/foods` | Get all food items |
| GET | `http://localhost:4000/foods/1` | Get one food item |
| POST | `http://localhost:4000/foods` | Add a food item |
| PUT | `http://localhost:4000/foods/1` | Update a food item |
| DELETE | `http://localhost:4000/foods/1` | Delete a food item |

### Example POST body

```json
{
  "id": 4,
  "foodName": "Cold Coffee",
  "category": "Beverage",
  "price": 120,
  "availability": true
}
```

### Example PUT body

```json
{
  "foodName": "Cheese Pizza",
  "category": "Fast Food",
  "price": 280,
  "availability": true
}
```

The PUT route updates the supplied fields while keeping the original ID. A positive numeric price is required.

## Notes

- Both servers are independent and use different ports. Run them in separate terminals.
- Data is stored in memory. New or changed records reset when the relevant server restarts.
- `node_modules/`, local environment files, logs and editor/OS clutter are excluded by `.gitignore`.
- Add your own genuine screenshots to the `screenshots/` folder after running and testing the application. Do not submit placeholder screenshots as proof of execution.

## Suggested Git commands

```bash
git init
git add .
git commit -m "Initial project setup"
git add httpServer.js public/menu.html
git commit -m "Implement native HTTP server and static menu"
git add expressApp.js
git commit -m "Implement food management REST API"
git add README.md .gitignore package.json
git commit -m "Add project documentation and gitignore"
```
