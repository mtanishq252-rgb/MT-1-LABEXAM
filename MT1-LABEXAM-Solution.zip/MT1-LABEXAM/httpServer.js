import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = 3000;

// Sample food records for the native HTTP server.
const foods = [
  { id: 1, foodName: "Pizza", category: "Fast Food", price: 250, availability: true },
  { id: 2, foodName: "Burger", category: "Fast Food", price: 120, availability: true },
  { id: 3, foodName: "Pasta", category: "Italian", price: 180, availability: false }
];

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data, null, 2));
}

function readRequestBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";

    req.on("data", (chunk) => {
      body += chunk;
      // Avoid accepting an unnecessarily large request body.
      if (body.length > 1_000_000) {
        reject(new Error("Request body is too large."));
        req.destroy();
      }
    });

    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        reject(new Error("Invalid JSON. Please send a valid JSON request body."));
      }
    });

    req.on("error", reject);
  });
}

function hasRequiredFields(food) {
  return food &&
    food.id !== undefined &&
    typeof food.foodName === "string" && food.foodName.trim() !== "" &&
    typeof food.category === "string" && food.category.trim() !== "" &&
    typeof food.price === "number" && Number.isFinite(food.price) && food.price > 0 &&
    typeof food.availability === "boolean";
}

const server = http.createServer(async (req, res) => {
  const requestUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const pathname = requestUrl.pathname;

  // GET /
  if (req.method === "GET" && pathname === "/") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`
      <!DOCTYPE html>
      <html lang="en">
      <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Food Ordering</title></head>
      <body>
        <h1>Welcome to Food Ordering</h1>
        <p>Explore our food menu and place your order.</p>
        <p><a href="/menu">View Menu</a> | <a href="/foods">Available Foods (JSON)</a> | <a href="/about">About Us</a></p>
      </body>
      </html>
    `);
    return;
  }

  // GET /foods - show only available food items.
  if (req.method === "GET" && pathname === "/foods") {
    const availableFoods = foods.filter((food) => food.availability === true);
    return sendJson(res, 200, availableFoods);
  }

  // POST /add-food
  if (req.method === "POST" && pathname === "/add-food") {
    try {
      const newFood = await readRequestBody(req);

      if (!hasRequiredFields(newFood)) {
        return sendJson(res, 400, {
          message: "Missing or invalid fields. Required: id, foodName, category, positive price, availability (boolean)."
        });
      }

      if (foods.some((food) => String(food.id) === String(newFood.id))) {
        return sendJson(res, 400, { message: "A food item with this ID already exists." });
      }

      foods.push(newFood);
      return sendJson(res, 201, {
        message: "Food item added successfully",
        food: newFood
      });
    } catch (error) {
      return sendJson(res, 400, { message: error.message });
    }
  }

  // GET /about
  if (req.method === "GET" && pathname === "/about") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`
      <!DOCTYPE html>
      <html lang="en">
      <head><meta charset="UTF-8"><title>About Us</title></head>
      <body>
        <h1>About Our Restaurant</h1>
        <p>We provide a variety of tasty food items for our customers.</p>
        <a href="/">Back to Home</a>
      </body>
      </html>
    `);
    return;
  }

  // GET /menu - serve public/menu.html using the FS module.
  if (req.method === "GET" && pathname === "/menu") {
    const menuPath = path.join(__dirname, "public", "menu.html");

    fs.readFile(menuPath, "utf8", (error, html) => {
      if (error) {
        return sendJson(res, 500, { message: "Unable to read the menu file." });
      }

      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(html);
    });
    return;
  }

  return sendJson(res, 404, { message: "Route not found." });
});

server.listen(PORT, () => {
  console.log(`HTTP Server running at http://localhost:${PORT}`);
});
