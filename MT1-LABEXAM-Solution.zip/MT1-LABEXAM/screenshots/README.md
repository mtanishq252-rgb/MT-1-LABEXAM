# Screenshots

Save your own practical screenshots in this folder:

1. HTTP server terminal showing port 3000.
2. Browser showing `/` and `/menu`.
3. Browser showing `/foods` JSON response.
4. Express server terminal showing port 4000.
5. Postman GET `/foods` and GET `/foods/1`.
6. Postman POST, PUT and DELETE requests with their responses.

These are submission evidence and should be captured after running the project. No screenshots are fabricated or included.
